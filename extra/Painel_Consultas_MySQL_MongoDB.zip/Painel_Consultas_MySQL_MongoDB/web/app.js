'use strict';
const $ = (selector) => document.querySelector(selector);
const token = $('meta[name="session-token"]').content;
const state = {queries: [], selected: null, result: null, page: 1, size: 25, sort: null, busy: false, engine: "mysql"};
const integer = new Intl.NumberFormat('pt-BR');
const decimalPattern = /^-?\d+\.\d+$/;
function numberLike(v) { return typeof v === 'number' || (typeof v === 'string' && decimalPattern.test(v)); }
function pretty(v) {
  if (v === null) return 'NULL';
  if (typeof v === 'number') return integer.format(v);
  if (/^\d{4}-\d{2}-\d{2}( |$)/.test(String(v))) {
    const [year, month, day] = v.slice(0, 10).split('-');
    return `${day}/${month}/${year}${v.length > 10 ? ' ' + v.slice(11).replace(/\.000000$/, '') : ''}`;
  }
  if (typeof v === 'string' && decimalPattern.test(v)) return v.replace('.', ',');
  return String(v);
}
function status(title, message, error = false) {
  const node = $('#status'); node.replaceChildren();
  node.className = 'empty-state' + (error ? ' error' : '');
  const icon = document.createElement('div'); icon.className = 'empty-icon'; icon.textContent = error ? '!' : '▤'; icon.setAttribute('aria-hidden', 'true');
  const h = document.createElement('h3'); h.textContent = title;
  const p = document.createElement('p'); p.textContent = message;
  node.append(icon, h, p); node.hidden = false;
  $('#table-wrap').hidden = true; $('#pagination').hidden = true;
}
function selectQuery(q) {
  $('#json-documents').hidden = true;
  $('#documents-code').textContent = '';
  $('#source-note').textContent = 'Fonte: ' + q.source.split('/').pop();
  state.selected = q; state.result = null; state.sort = null; state.page = 1;
  $('#query-title').textContent = q.title; $('#question').textContent = q.question;
  $('#sql-code').textContent = q.sql;
  $('#tags').replaceChildren();
  for (const tag of q.tags) { const span = document.createElement('span'); span.className = 'tag' + (tag === 'VIEW' ? ' view' : ''); span.textContent = tag; $('#tags').append(span); }
  for (const item of document.querySelectorAll('.nav-query')) { const active = Number(item.dataset.id) === q.id; item.classList.toggle('active', active); if (active) item.setAttribute('aria-current', 'page'); else item.removeAttribute('aria-current'); }
  $('#result-meta').textContent = 'Execute a consulta para visualizar os dados.';
  $('#search').value = ''; $('#search').disabled = true; $('#run').disabled = false;
  status('Consulta pronta para execução.', 'Os resultados serão obtidos diretamente da base ' + (q.engine === 'mysql' ? 'MySQL' : 'MongoDB') + ' conectada.');
}
function filteredRows() {
  if (!state.result) return [];
  const term = $('#search').value.trim().toLocaleLowerCase('pt-BR');
  let rows = state.result.rows.filter(row => !term || row.some(v => pretty(v).toLocaleLowerCase('pt-BR').includes(term)));
  if (state.sort) { const {column, direction} = state.sort; rows = [...rows].sort((a, b) => {
    if (a[column] === null) return b[column] === null ? 0 : 1;
    if (b[column] === null) return -1;
    const n = numberLike(a[column]) && numberLike(b[column]);
    const cmp = n ? Number(a[column]) - Number(b[column]) : String(a[column]).localeCompare(String(b[column]), 'pt-BR', {numeric: true});
    return cmp * direction;
  }); }
  return rows;
}
function renderRows() {
  const result = state.result; if (!result) return;
  const rows = filteredRows(); const pages = Math.max(1, Math.ceil(rows.length / state.size)); state.page = Math.min(state.page, pages);
  const limited = result.limited ? ` · Limite de ${integer.format(result.limit)} linhas` : '';
  $('#result-meta').textContent = `${integer.format(rows.length)} ${rows.length === 1 ? 'registro' : 'registros'}${rows.length !== result.count ? ' de ' + integer.format(result.count) : ''} · ${String(result.duration_ms).replace('.', ',')} ms${limited}`;
  if (!rows.length) { status(result.count ? 'Nenhum resultado para esta busca.' : 'A consulta não retornou registros.', result.count ? 'Experimente outro termo para filtrar os resultados.' : 'Nenhum registro corresponde aos critérios desta consulta.'); return; }
  $('#status').hidden = true; $('#table-wrap').hidden = false; $('#pagination').hidden = false;
  const head = $('#table thead'); head.replaceChildren(); const tr = document.createElement('tr');
  result.columns.forEach((name, column) => {
    const th = document.createElement('th'); th.scope = 'col';
    const sorted = state.sort?.column === column;
    th.setAttribute('aria-sort', sorted ? (state.sort.direction === 1 ? 'ascending' : 'descending') : 'none');
    const button = document.createElement('button'); button.textContent = name.replaceAll('_', ' ') + (sorted ? (state.sort.direction === 1 ? ' ↑' : ' ↓') : '');
    button.title = `Ordenar por ${name}`; button.addEventListener('click', () => { state.sort = {column, direction: sorted ? -state.sort.direction : 1}; state.page = 1; renderRows(); });
    th.append(button); tr.append(th);
  }); head.append(tr);
  const body = $('#table tbody'); body.replaceChildren();
  for (const row of rows.slice((state.page - 1) * state.size, state.page * state.size)) {
    const line = document.createElement('tr');
    row.forEach((value, i) => {
      const cell = document.createElement('td'); const label = pretty(value);
      if (value === null) {cell.className = 'null';cell.title = 'Ausência de valor';}
      else if (numberLike(value)) cell.className = 'number';
      else if (/^\d{4}-\d{2}-\d{2}( |$)/.test(String(value))) cell.className = 'date';
      if (result.columns[i] === 'situacao') {const badge = document.createElement('span'); badge.textContent = label; badge.className = 'badge ' + ({CONCLUIDA:'closed',ENCERRADO:'closed','EM TRATAMENTO':'working',RECONHECIDO:'working',ABERTO:'open',ABERTA:'open'}[value] || 'open'); cell.append(badge);}
      else cell.textContent = label;
      line.append(cell);
    }); body.append(line);
  }
  $('#page-info').textContent = `${(state.page-1)*state.size+1}–${Math.min(state.page*state.size,rows.length)} de ${integer.format(rows.length)}`;
  $('#previous').disabled = state.page === 1; $('#next').disabled = state.page === pages;
}
async function runQuery() {
  if (state.busy || !state.selected) return;
  state.busy = true; for (const b of document.querySelectorAll('.engine-tab')) b.disabled=true; $('#run').disabled = true; $('#run').textContent = 'Consultando…';
  for (const b of document.querySelectorAll('.nav-query')) b.disabled = true;
  state.result = null; $('#json-documents').hidden = true; $('#search').disabled = true;
  status('Consultando a base…', 'Aguarde o retorno da consulta selecionada.');
  $('#result-meta').textContent = 'Executando consulta no ' + (state.engine === 'mysql' ? 'MySQL.' : 'MongoDB.');
  try {
    const response = await fetch('/api/consultar', {method:'POST', headers:{'Content-Type':'application/json','X-Session-Token':token},body:JSON.stringify({id:state.selected.id})});
    const result = await response.json(); if (!response.ok) throw new Error(result.error || 'Não foi possível consultar a base.');
    state.result = result;
    $('#json-documents').hidden = !result.documents?.length;
    $('#documents-code').textContent = result.documents ? JSON.stringify(result.documents, null, 2) : '';
    state.page = 1; state.sort = null; $('#search').value = ''; $('#search').disabled = result.count === 0; renderRows();
  } catch (error) {$('#result-meta').textContent = 'Consulta não concluída.'; status('Não foi possível obter os resultados.',error.message || 'Verifique se o painel e o MySQL continuam em execução.',true);}
  finally {state.busy = false; for (const b of document.querySelectorAll('.engine-tab')) b.disabled=false; $('#run').disabled = false; $('#run').replaceChildren(); const icon = document.createElement('span');icon.setAttribute('aria-hidden','true');icon.textContent='▶';$('#run').append(icon,document.createTextNode(' Executar consulta'));for(const b of document.querySelectorAll('.nav-query'))b.disabled=false;}
}
$('#run').addEventListener('click',runQuery);
$('#toggle-sql').addEventListener('click',()=>{const open=$('#sql-panel').hidden;$('#sql-panel').hidden=!open;$('#toggle-sql').setAttribute('aria-expanded',String(open));$('#toggle-sql').textContent=open?'Ocultar código':'Ver código';});
$('#copy-sql').addEventListener('click',async()=>{try {await navigator.clipboard.writeText(state.selected.sql);$('#copy-sql').textContent='Código copiado';} catch {$('#copy-sql').textContent='Selecione e copie o código abaixo';} setTimeout(()=>{$('#copy-sql').textContent='Copiar código';},2200);});
$('#search').addEventListener('input',()=>{state.page=1;renderRows();});
$('#page-size').addEventListener('change',()=>{state.size=Number($('#page-size').value);state.page=1;renderRows();});
$('#previous').addEventListener('click',()=>{state.page--;renderRows();});
$('#next').addEventListener('click',()=>{state.page++;renderRows();});
(async()=>{try {
 const response=await fetch('/api/catalogo');if(!response.ok)throw new Error('Catálogo indisponível.');
 const data=await response.json();state.queries=data.queries;$('#base-label').textContent=data.database;

 function chooseEngine(engine) {
   state.engine = engine;
   $('#catalog').replaceChildren();
   for (const tab of document.querySelectorAll('.engine-tab')) {
     const active=tab.dataset.engine === engine;
     tab.classList.toggle('active',active);tab.setAttribute('aria-selected',String(active));
   }
   const title=engine === 'mysql' ? 'MySQL' : 'MongoDB';
   $('#engine-label').textContent=title;
   $('#breadcrumb-engine').textContent='Consultas '+title;
   $('#section-label').textContent='CONSULTAS '+title.toUpperCase();
   const visible=state.queries.filter(q=>q.engine===engine);
   for(const q of visible){const b=document.createElement('button');b.className='nav-query';b.dataset.id=q.id;const n=document.createElement('span');n.className='nav-number';n.textContent=String(q.number).padStart(2,'0');const label=document.createElement('span');label.textContent=q.title;b.append(n,label);b.addEventListener('click',()=>selectQuery(q));$('#catalog').append(b);}
   selectQuery(visible[0]);
 }
 for (const b of document.querySelectorAll('.engine-tab')) b.addEventListener('click',()=>chooseEngine(b.dataset.engine));
 chooseEngine('mysql');
}catch {$('#base-label').textContent='Servidor indisponível';status('O catálogo não pôde ser carregado.','Reabra o painel pelo arquivo iniciar.bat.',true);}})();
