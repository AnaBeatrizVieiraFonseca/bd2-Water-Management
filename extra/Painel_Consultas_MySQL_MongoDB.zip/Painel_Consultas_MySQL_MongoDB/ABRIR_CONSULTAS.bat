@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto bibliotecas
py -3.14 --version >nul 2>&1
if errorlevel 1 goto sem_python
py -3.14 -m venv .venv
if errorlevel 1 goto erro
:bibliotecas
".venv\Scripts\python.exe" -c "import mysql.connector; import pymongo" >nul 2>&1
if not errorlevel 1 goto executar
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto erro
:executar
".venv\Scripts\python.exe" servidor.py
if errorlevel 1 goto erro
exit /b 0
:sem_python
echo Instale o Python 3.14 de 64 bits para iniciar este painel.
pause
exit /b 1
:erro
echo Nao foi possivel iniciar. Confira a mensagem acima.
pause
exit /b 1
