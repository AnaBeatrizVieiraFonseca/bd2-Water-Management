"""Painel local de consultas. As credenciais permanecem na memória do processo."""
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from datetime import datetime, date, time
from decimal import Decimal
from getpass import getpass
import argparse
import json
import secrets
import threading
import time as clock
import webbrowser

import mysql.connector
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from bson import json_util, ObjectId, Decimal128

ROOT = Path(__file__).resolve().parent
MAX_ROWS = 5000


def load_queries():
    entries = json_util.loads((ROOT / 'consultas.json').read_text(encoding='utf-8'))
    if len(entries) != 20 or {q['id'] for q in entries} != set(range(1, 21)):
        raise ValueError('O catálogo deve conter dez consultas de cada banco.')
    for q in entries:
        if q['engine'] == 'mysql':
            sql = q['sql'].strip().rstrip(';')
            if not sql.upper().startswith('SELECT ') or ';' in sql:
                raise ValueError('Somente SELECT individual é permitido.')
        elif q['engine'] != 'mongodb' or q.get('kind') != 'find':
            raise ValueError('Somente consultas MongoDB find catalogadas são permitidas.')
        elif q['collection'] not in {'medicoes', 'telemetria', 'logs_ingestao'}:
            raise ValueError('Collection fora do catálogo.')
    return {q['id']: q for q in entries}


def json_value(value):
    if isinstance(value, ObjectId):
        return str(value)
    if isinstance(value, Decimal128):
        return str(value.to_decimal())
    if isinstance(value, dict):
        return {k: json_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [json_value(v) for v in value]
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (datetime, date, time)):
        return value.isoformat(sep=' ') if isinstance(value, datetime) else value.isoformat()
    if isinstance(value, bytes):
        return value.decode('utf-8', errors='replace')
    return value


def execute_mysql(config, entry):
    connection = mysql.connector.connect(**config, autocommit=False, connection_timeout=10)
    cursor = None
    try:
        cursor = connection.cursor()
        cursor.execute("SET time_zone = '+00:00'")
        connection.commit()
        connection.start_transaction(readonly=True)
        started = clock.perf_counter()
        cursor.execute(entry['sql'])
        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchmany(MAX_ROWS + 1)
        duration = round((clock.perf_counter() - started) * 1000, 1)
        limited = len(rows) > MAX_ROWS
        result = [[json_value(v) for v in row] for row in rows[:MAX_ROWS]]
        # Consume the remaining result so the connector can close normally.
        if limited:
            while cursor.fetchmany(1000):
                pass
        connection.rollback()
        return {'columns': columns, 'rows': result, 'count': len(result),
                'limited': limited, 'limit': MAX_ROWS, 'duration_ms': duration}
    finally:
        if cursor is not None:
            cursor.close()
        connection.close()


def execute_mongo(config, entry):
    started = clock.perf_counter()
    with MongoClient('mongodb://localhost:27017', tz_aware=True,
                     serverSelectionTimeoutMS=5000, socketTimeoutMS=20000) as client:
        collection = client[config['database']][entry['collection']]
        cursor = collection.find(entry['filter'], entry.get('projection'))
        if entry.get('sort'):
            cursor = cursor.sort(list(entry['sort'].items()))
        cursor = cursor.limit(min(entry.get('limit', 100), MAX_ROWS)).max_time_ms(15000)
        try:
            documents = [json_value(d) for d in cursor]
        finally:
            cursor.close()
    def flatten(d, prefix=''):
        out = {}
        for key, value in d.items():
            name = prefix + key
            if isinstance(value, dict):
                if value:
                    out.update(flatten(value, name + '.'))
                else:
                    out[name] = '{}'
            elif isinstance(value, list):
                out[name] = json.dumps(value, ensure_ascii=False)
            else:
                out[name] = value
        return out
    flat = [flatten(d) for d in documents]
    columns = list(dict.fromkeys(k for d in flat for k in d))
    rows = [[d.get(k) for k in columns] for d in flat]
    return {'columns': columns, 'rows': rows, 'documents': documents,
            'count': len(rows), 'limited': False, 'limit': MAX_ROWS,
            'duration_ms': round((clock.perf_counter() - started) * 1000, 1)}


def execute_query(config, entry):
    return execute_mysql(config, entry) if entry['engine'] == 'mysql' else execute_mongo(config, entry)


class PanelServer(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, config):
        self.config = dict(config)
        self.catalog = load_queries()
        self.token = secrets.token_urlsafe(32)
        super().__init__(address, Handler)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def allowed_host(self):
        port = self.server.server_address[1]
        return self.headers.get('Host') in {f'127.0.0.1:{port}', f'localhost:{port}'}

    def send(self, status, body, content_type='application/json; charset=utf-8'):
        if not isinstance(body, bytes):
            body = json.dumps(body, ensure_ascii=False, allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self.allowed_host():
            return self.send(403, {'error': 'Origem não autorizada.'})
        if self.path == '/api/catalogo':
            return self.send(200, {'queries': [{k: q[k] for k in ('id','number','engine','title','question','sql','tags','source')} for q in self.server.catalog.values()],
                'database': self.server.config['database']})
        assets = {'/': ('index.html', 'text/html; charset=utf-8'),
                  '/app.js': ('app.js', 'text/javascript; charset=utf-8'),
                  '/style.css': ('style.css', 'text/css; charset=utf-8')}
        if self.path not in assets:
            return self.send(404, {'error': 'Recurso não encontrado.'})
        name, content_type = assets[self.path]
        body = (ROOT / 'web' / name).read_bytes()
        if name == 'index.html':
            body = body.replace(b'__SESSION_TOKEN__', self.server.token.encode('ascii'))
        self.send(200, body, content_type)

    def do_POST(self):
        port = self.server.server_address[1]
        origin = self.headers.get('Origin')
        if (not self.allowed_host() or origin not in {f'http://127.0.0.1:{port}', f'http://localhost:{port}'}
                or not secrets.compare_digest(self.headers.get('X-Session-Token', ''), self.server.token)):
            return self.send(403, {'error': 'Requisição não autorizada.'})
        if self.path != '/api/consultar':
            return self.send(404, {'error': 'Recurso não encontrado.'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 1000 or self.headers.get_content_type() != 'application/json':
                return self.send(400, {'error': 'Requisição inválida.'})
            payload = json.loads(self.rfile.read(length))
            ident = payload.get('id')
            if type(ident) is not int or ident not in self.server.catalog or set(payload) != {'id'}:
                return self.send(400, {'error': 'Selecione uma das consultas do catálogo.'})
            result = execute_query(self.server.config, self.server.catalog[ident])
            self.send(200, result)
        except (ValueError, TypeError, AttributeError):
            self.send(400, {'error': 'Requisição inválida.'})
        except mysql.connector.Error as error:
            messages = {1045: 'Credenciais MySQL recusadas. Reinicie o painel e confira a conta.',
                        1142: 'A conta não possui acesso a uma tabela utilizada nesta consulta.',
                        1143: 'A conta não possui acesso aos campos necessários.',
                        1146: 'Uma tabela ou view necessária não foi encontrada na base selecionada.',
                        2003: 'Não foi possível conectar ao MySQL. Verifique se o serviço está em execução.'}
            self.send(503, {'error': messages.get(error.errno, f'Falha na consulta MySQL (código {error.errno}).')})
        except PyMongoError:
            self.send(503, {'error': 'Não foi possível consultar o MongoDB local. Confira o serviço e a carga recursos_hidricos.'})
        except Exception:
            self.send(500, {'error': 'Não foi possível executar a consulta.'})


def connection_dialog(defaults):
    import tkinter as tk
    from tkinter import ttk, messagebox
    window = tk.Tk()
    window.title('Consultas MySQL e MongoDB | Recursos hídricos')
    window.resizable(False, False)
    frame = ttk.Frame(window, padding=24)
    frame.grid()
    ttk.Label(frame, text='Conexão MySQL para o painel de consultas', font=('Segoe UI', 14, 'bold')).grid(row=0, column=0, columnspan=2, sticky='w', pady=(0, 15))
    entries = {}
    fields = [('host', 'Servidor'), ('port', 'Porta'), ('database', 'Base'), ('user', 'Usuário'), ('password', 'Senha')]
    for row, (key, title) in enumerate(fields, 1):
        ttk.Label(frame, text=title).grid(row=row, column=0, sticky='w', padx=(0, 15), pady=5)
        value = tk.StringVar(value=str(defaults.get(key, '')))
        box = ttk.Entry(frame, textvariable=value, width=33, show='*' if key == 'password' else '')
        box.grid(row=row, column=1, pady=5)
        entries[key] = value
        if key == 'password':box.focus_set()
    ttk.Label(frame, text='A senha é utilizada somente durante esta execução.').grid(row=6, column=0, columnspan=2, sticky='w', pady=(12, 10))
    result = []
    def connect(*_):
        try:
            config = {k: value.get() for k, value in entries.items()}
            config['port'] = int(config['port'])
            connection = mysql.connector.connect(**config, connection_timeout=7)
            connection.close()
            result.append(config)
            window.destroy()
        except Exception:
            messagebox.showerror('Conexão MySQL', 'Não foi possível conectar. Verifique o servidor, a base, o usuário e a senha.', parent=window)
    ttk.Button(frame, text='Abrir painel', command=connect).grid(row=7, column=0, columnspan=2, sticky='ew')
    window.bind('<Return>', connect)
    window.mainloop()
    return result[0] if result else None


def main():
    parser = argparse.ArgumentParser(description='Painel local separado com dez consultas MySQL e dez MongoDB.')
    parser.add_argument('--host', default='localhost')
    parser.add_argument('--port', type=int, default=3306)
    parser.add_argument('--base', default='recursos_hidricos')
    parser.add_argument('--usuario', default='rh_admin_projeto')
    parser.add_argument('--terminal', action='store_true')
    parser.add_argument('--sem-browser', action='store_true')
    args = parser.parse_args()
    config = {'host': args.host, 'port': args.port, 'database': args.base, 'user': args.usuario}
    if args.terminal:
        config['password'] = getpass('Senha MySQL: ')
        connection = mysql.connector.connect(**config, connection_timeout=7)
        connection.close()
    else:
        config = connection_dialog(config)
        if config is None:return
    server = PanelServer(('127.0.0.1', 0), config)
    url = f'http://127.0.0.1:{server.server_address[1]}'
    print('Painel de consultas MySQL e MongoDB: ' + url)
    print('Para encerrar, pressione Ctrl+C nesta janela.')
    if not args.sem_browser:
        threading.Timer(.5, lambda: webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()


if __name__ == '__main__':
    try:main()
    except Exception:
        print('Não foi possível iniciar o painel. Confira a instalação e a conexão MySQL.')
        raise SystemExit(1)
